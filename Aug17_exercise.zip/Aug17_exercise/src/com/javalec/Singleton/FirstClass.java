package com.javalec.Singleton;

public class FirstClass {
	public FirstClass() {
		// TODO Auto-generated constructor stub
		Singleton singleton = Singleton.getSinglton();
		System.out.println(singleton.i);
		singleton.setI(20);
		System.out.println(singleton.i);
		
	}
}
