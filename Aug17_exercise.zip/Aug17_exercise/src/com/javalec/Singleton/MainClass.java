package com.javalec.Singleton;

public class MainClass {
	public static void main(String[] args) {
		SecondClass b = new SecondClass();
		FirstClass a = new FirstClass();
		
	}
}
