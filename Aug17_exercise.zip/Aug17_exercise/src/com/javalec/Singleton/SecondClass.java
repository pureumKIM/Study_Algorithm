package com.javalec.Singleton;

public class SecondClass {
	public SecondClass() {
		// TODO Auto-generated constructor stub
		Singleton b = Singleton.getSinglton();
		System.out.println(b.i);
		b.setI(40);
		System.out.println(b.i);
	}
}
