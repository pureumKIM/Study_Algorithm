package com.pureum.ChildHouse;

public class A extends LunchMenu{
	
	public A(int gogi, int rice) {
		// TODO Auto-generated constructor stub
		super(gogi, rice);
	}
	@Override
	public int cal() {
		// TODO Auto-generated method stub
		return gogi;
	}

}
