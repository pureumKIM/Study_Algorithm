package com.pureum.ChildHouse;

public class B extends LunchMenu {

	public B(int gogi, int rice) {
		super(gogi, rice);
		// TODO Auto-generated constructor stub
	}

	@Override
	public int cal() {
		// TODO Auto-generated method stub
		return rice;
	}

}
