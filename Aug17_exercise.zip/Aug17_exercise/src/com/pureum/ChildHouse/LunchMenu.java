package com.pureum.ChildHouse;

public abstract class LunchMenu {
	public int gogi;
	public int rice;
	public LunchMenu(int gogi, int rice) {
		// TODO Auto-generated constructor stub
		this.gogi = gogi;
		this.rice = rice;
	}
	public abstract int cal();
}
