package com.pureum.ChildHouse;

public class MainClass {
	public static void main(String[] args) {
		A a = new A(PriceTable.GOGI, PriceTable.RICE);
		B b = new B(PriceTable.GOGI, PriceTable.RICE);
		System.out.println(a.cal());
		System.out.println(b.cal());
	}
}
