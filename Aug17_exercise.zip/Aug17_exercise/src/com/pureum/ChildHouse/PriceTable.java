package com.pureum.ChildHouse;

public class PriceTable {
	public static int GOGI = 1000;
	public static int RICE = 500;
}
