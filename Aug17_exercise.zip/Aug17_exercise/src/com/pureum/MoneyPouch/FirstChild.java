package com.pureum.MoneyPouch;

public class FirstChild implements bro {
	public FirstChild() {
		// TODO Auto-generated constructor stub
	}
	public void takemoney() {
		// TODO Auto-generated method stub
		PapaPouch.MONEY -= 100;
	}
}
