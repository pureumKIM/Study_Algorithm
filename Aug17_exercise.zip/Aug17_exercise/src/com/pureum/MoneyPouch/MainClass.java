package com.pureum.MoneyPouch;

public class MainClass {
	public static void main(String[] args) {
		bro a = new FirstChild();
		bro b = new SecondChild();
		bro c = new ThirdChild();
		a.takemoney();
		b.takemoney();
		c.takemoney();
		System.out.println(PapaPouch.MONEY);
	}
}
