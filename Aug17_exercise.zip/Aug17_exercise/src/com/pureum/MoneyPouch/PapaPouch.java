package com.pureum.MoneyPouch;

public class PapaPouch {
	public PapaPouch() {
		// TODO Auto-generated constructor stub
	}
	public static int MONEY = 200;
}
