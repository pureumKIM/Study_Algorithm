package com.pureum.MoneyPouch;

public class SecondChild implements bro  {
	public void takemoney() {
		// TODO Auto-generated method stub
		PapaPouch.MONEY -= 100;
	}
}
