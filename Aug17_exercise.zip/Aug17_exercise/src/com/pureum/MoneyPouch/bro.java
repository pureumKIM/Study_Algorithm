package com.pureum.MoneyPouch;

public interface bro {
	void takemoney();
}
