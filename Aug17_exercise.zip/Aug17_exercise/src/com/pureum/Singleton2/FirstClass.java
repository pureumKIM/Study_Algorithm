package com.pureum.Singleton2;

public class FirstClass {
	public FirstClass() {
		// TODO Auto-generated constructor stub
		Singleton singleton = Singleton.getSigleton();
		System.out.println(singleton.i);
		singleton.setI(30);
	}
}
