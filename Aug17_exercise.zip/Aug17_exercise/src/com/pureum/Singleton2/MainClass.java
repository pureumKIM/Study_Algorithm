package com.pureum.Singleton2;

public class MainClass {

}
