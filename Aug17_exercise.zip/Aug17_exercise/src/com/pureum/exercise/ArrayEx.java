package com.pureum.exercise;

public class ArrayEx {
	public static void main(String[] args) {
		int[] Arr = new int[5];
		Arr[0]=1;
		Arr[1]=2;
		Arr[2]=3;
		Arr[3]=4;
		Arr[4]=5;
		System.out.println("배열의 길이는 "+Arr.length);
		System.out.println("두번째 요소의 값은  "+Arr[1]);
	}
}
