package com.pureum.exercise;

import java.util.Scanner;

public class AvgTest {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("국어점수를 입력하세요!");
		int kor = sc.nextInt();
		System.out.println("수학점수를 입력하세요!");
		int mat = sc.nextInt();
		System.out.println("영어점수를 입력하세요!");
		int eng = sc.nextInt();
		int avg = (kor+mat+eng)/3;
		System.out.println("평균은 : "+avg+"입니다.");
	}
}
