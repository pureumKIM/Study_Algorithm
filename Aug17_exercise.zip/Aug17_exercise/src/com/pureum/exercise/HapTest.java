package com.pureum.exercise;

public class HapTest {
	public static void main(String[] args) {
		int num = 10;
		int evenHap = 0;
		int oddHap = 0;
		for(int i=1; i<=num; i++){
			if(i%2 == 0){
				evenHap += i;
			}else{
				oddHap += i;
			}
		}
		System.out.println("1부터 "+num+" 짝수들의 합은 "+evenHap);
		System.out.println("1부터 "+num+" 홀수들의 합은 "+oddHap);
	}
}
