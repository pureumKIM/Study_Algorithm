package com.pureum.exercise;

import java.util.Scanner;

public class HeightTest {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String[] fName = {"은섭","지향","푸름","잔디","민중"};
		double [] fHeight = new double[5];
		
		for(int k=0; k<fHeight.length; k++){
			System.out.println(fName[k]+"의 키를 입력해주세요");
			fHeight[k] = sc.nextDouble();
		}
		int minN=0;
		int maxN=0;
		double minH=0;
		double maxH=0;
		double sum =0;
		double avg =0;
		
		for(int i =0; i<fHeight.length; i++){
			sum += fHeight[i];
		}
		
		avg = sum/fHeight.length;
		System.out.println("가족 키의 평균은 : "+avg+"입니다.");
		
		for(int i = 0 ; i<fHeight.length; i++){
			if(maxH<fHeight[i]){
				maxH = fHeight[i];
				maxN = i;
			}
		}
		System.out.println("가장 키큰 사람은"+fName[maxN]+"입니다.");	
		System.out.println("그 키는"+fHeight[maxN]+"입니다.");	
		
		minH = maxH;
		
		for(int j=0; j<fHeight.length; j++){
			if(minH>fHeight[j]){
				minH = fHeight[j];
				minN = j;
			}
		}
		System.out.println("가장 키가 작은 사람은"+fName[minN]+"입니다.");	
		System.out.println("그 키는"+fHeight[minN]+"입니다.");
	}
}
