package com.pureum.exercise;

public class MethodGugu {
	public static void main(String[] args) {
		MethodGugu gugu = new MethodGugu();
		gugu.gugu(4);
	}
	
	public void gugu(int num) {
		// TODO Auto-generated method stub
		for(int i=1; i<10; i++){
			System.out.println(num+"*"+i+"="+(num*i));
		}
	}
}
