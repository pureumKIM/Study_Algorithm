package com.pureum.exercise;

public class WhileTreeHap {
	public static void main(String[] args) {
		int i = 0;
		int end = 100;
		int hap = 0;
		while(true){
			hap = hap +i;
			i = i+3;//
			if(i>end) break;
		}
		System.out.println("1부터 100까지 3의 배수의 합은 : "+hap);
	}
}
