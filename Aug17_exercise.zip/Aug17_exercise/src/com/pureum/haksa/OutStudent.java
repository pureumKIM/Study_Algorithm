package com.pureum.haksa;

import java.util.ArrayList;

public class OutStudent {
	ArrayList<Student> outers;
	public OutStudent() {
		// TODO Auto-generated constructor stub
		outers = new ArrayList<Student>();
	}
	
	public void addOuter(String name, int age, int score) {
		// TODO Auto-generated method stub
		outers.add(new Student(name,age,score));
	}
}
