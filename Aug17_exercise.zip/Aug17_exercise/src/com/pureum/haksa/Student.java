package com.pureum.haksa;

public class Student {
	private String name;
	private int age;
	private int score;
	
	public Student(String name, int age, int score) {
		// TODO Auto-generated constructor stub
		this.name = name;
		this.age = age;
		this.score = score;
	}
	public void update(int i, String update) {
		// TODO Auto-generated method stub
		switch (i) {
		case 0:
			setName(update);
			break;
		case 1:
			setAge(Integer.parseInt(update));
			break;
		case 2:
			setScore(Integer.parseInt(update));
			break;

		default:
			break;
		}
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}
	
}
