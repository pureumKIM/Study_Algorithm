package com.pureum.haksa;

import java.util.ArrayList;

public class StudentManager {
	ArrayList<Student> students = new ArrayList<Student>();
	OutStudent outs = new OutStudent();
	public static void main(String[] args) {
		StudentManager sm = new StudentManager();
		sm.addStudent("푸름", 24, 100);
		System.out.println(sm.students.get(0).getName());
		sm.students.get(0).update(0, "잔디");
		System.out.println(sm.students.get(0).getName());
	}
	
	public void addStudent(String name, int age, int score) {
		// TODO Auto-generated method stub
		students.add(new Student(name,age,score));
	}
}
