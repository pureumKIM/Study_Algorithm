package com.pureum.phone;

public class MainClass {
	public static void main(String[] args) {
		Phone a = new APhone();
		Phone b = new BPhone();
		Phone c = new CPhone();
		
		Phone[] phones = {a,b,c};
		
		for(int i=0; i< phones.length; i++){
			phones[i].call();
			phones[i].lte();
			phones[i].remote();
		}
	}
}
