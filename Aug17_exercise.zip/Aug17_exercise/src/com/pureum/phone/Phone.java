package com.pureum.phone;

public interface Phone {
	void lte();
	void remote();
	void call();
}
