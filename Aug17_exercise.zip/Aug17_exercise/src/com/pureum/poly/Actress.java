package com.pureum.poly;

public class Actress implements ICook, IFireFiter, IPolice {

	@Override
	public void findChild() {
		// TODO Auto-generated method stub
		System.out.println("아이 찾아주기");
	}

	@Override
	public void arrange() {
		// TODO Auto-generated method stub
		System.out.println("교통정리하기");
	}

	@Override
	public void putOut() {
		// TODO Auto-generated method stub
		System.out.println("불끄기");
	}

	@Override
	public void savePerson() {
		// TODO Auto-generated method stub
		System.out.println("사람 구하기");
	}

	@Override
	public void makeRamen() {
		// TODO Auto-generated method stub
		System.out.println("라면 만들기");
	}

	@Override
	public void makeCake() {
		// TODO Auto-generated method stub
		System.out.println("케이크 만들기");
	}

}
