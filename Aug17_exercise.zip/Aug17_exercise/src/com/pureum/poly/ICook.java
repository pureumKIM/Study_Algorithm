package com.pureum.poly;

public interface ICook {
	void makeRamen();
	void makeCake();
}
