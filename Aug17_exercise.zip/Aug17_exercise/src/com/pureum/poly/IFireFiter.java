package com.pureum.poly;

public interface IFireFiter {
	void putOut();
	void savePerson();
}
