package com.pureum.poly;

public interface IPolice {
	void findChild();
	void arrange();
}
