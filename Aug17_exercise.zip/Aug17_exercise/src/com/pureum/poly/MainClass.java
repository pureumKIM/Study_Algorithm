package com.pureum.poly;

public class MainClass {
	public static void main(String[] args) {
		ICook cook = new Actress();
		cook.makeCake();
		cook.makeRamen();
		Actress pureum = new Actress();
		pureum.makeCake();
		pureum.savePerson();
		pureum.arrange();
	}
}
