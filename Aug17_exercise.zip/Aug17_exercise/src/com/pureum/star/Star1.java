package com.pureum.star;

public class Star1 {
	public static void main(String[] args) {
		int num =5;
		for(int i=0; i<5; i++){
			for(int k=0; k<num-i-1;k++){
				System.out.print(" ");
			}
			for(int j=0; j<i+1; j++){
				System.out.print("*");
			}
			System.out.println();
		}
	}
}
