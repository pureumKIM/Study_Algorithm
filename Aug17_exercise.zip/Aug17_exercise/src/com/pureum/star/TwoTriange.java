package com.pureum.star;

public class TwoTriange {
	public static void main(String[] args) {
		int num =5;
		for(int i=0; i<num*2; i++){
			if(i<num){//별 줄어는 것
				for(int j=0; j<i; j++){
					System.out.print(" ");
				}
				for(int j=1; j<(num-i)*2; j++){
					System.out.print("*");
				}
				System.out.println();
			}else{
				for(int k=0; k<num-(i-num)-1; k++){
					System.out.print(" ");
				}
				for(int k=0; k<(i-num+1)*2-1; k++){
					System.out.print("*");
				}
				System.out.println();
			}
		}
	}
}
