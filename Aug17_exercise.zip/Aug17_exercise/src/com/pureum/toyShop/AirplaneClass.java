package com.pureum.toyShop;

public class AirplaneClass implements Missile, Light {

	@Override
	public void canLight() {
		// TODO Auto-generated method stub
		System.out.println("빛을 낼 수 있어요");
	}

	@Override
	public void canMissile() {
		// TODO Auto-generated method stub
		System.out.println("미사일 발사할 수 있어요");
	}

}
