package com.pureum.toyShop;

public interface Light extends toy {
	void canLight();
}
