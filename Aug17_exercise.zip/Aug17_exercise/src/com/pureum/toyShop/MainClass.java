package com.pureum.toyShop;

public class MainClass {
	public static void main(String[] args) {
		toy pooh = new PoohClass();
		PoohClass pooh2 = new PoohClass();
		pooh2.canMove();
	}
}
