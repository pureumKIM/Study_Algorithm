package com.pureum.toyShop;

public interface Missile extends toy {
	void canMissile();
}
