package com.pureum.toyShop;

public interface Move extends toy {
	void canMove();
}
