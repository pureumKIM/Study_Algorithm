package com.pureum.toyShop;

public class PoohClass implements Move {

	@Override
	public void canMove() {
		// TODO Auto-generated method stub
		System.out.println("팔다리 움직일 수 있어요");
	}

}
