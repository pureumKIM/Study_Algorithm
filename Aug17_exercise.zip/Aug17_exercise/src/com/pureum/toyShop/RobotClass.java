package com.pureum.toyShop;

public class RobotClass implements Move, Light {

	@Override
	public void canLight() {
		// TODO Auto-generated method stub
		System.out.println("빛을 낼 수 있어요");
	}

	@Override
	public void canMove() {
		// TODO Auto-generated method stub
		System.out.println("팔다리 움직일 수 있어요");
	}

}
