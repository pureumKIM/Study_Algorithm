package com.pureum.toyShop;

public interface toy {

}
