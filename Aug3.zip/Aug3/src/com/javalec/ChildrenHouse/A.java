package com.javalec.ChildrenHouse;

public class A extends LunchMenu{

	public A(int ham, int dduk) {
		// TODO Auto-generated constructor stub
		super(ham, dduk);
	}
	@Override
	public int cal() {
		// TODO Auto-generated method stub
		return ham;
	}

}
