package com.javalec.ChildrenHouse;

public class B extends LunchMenu{

	public B(int ham, int dduk) {
		// TODO Auto-generated constructor stub
		super(ham, dduk);
	}
	@Override
	public int cal() {
		// TODO Auto-generated method stub
		return dduk;
	}

}
