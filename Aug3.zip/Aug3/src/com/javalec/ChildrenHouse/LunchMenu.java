package com.javalec.ChildrenHouse;

public abstract class LunchMenu {
	public int ham;
	public int dduk;
	
	public LunchMenu(int ham, int dduk) {
		// TODO Auto-generated constructor stub
		this.ham = ham;
		this.dduk = dduk;
	}
	
	public abstract int cal();
}
