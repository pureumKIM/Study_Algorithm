package com.javalec.ChildrenHouse;

public class MainClass {
	public static void main(String[] args) {
		LunchMenu a = new A(PT.HAM,PT.DDUK);
		LunchMenu b = new B(PT.HAM,PT.DDUK);
		System.out.println(a.cal());
		System.out.println(b.cal());
	}
}
