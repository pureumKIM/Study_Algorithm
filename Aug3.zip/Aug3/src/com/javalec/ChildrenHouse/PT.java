package com.javalec.ChildrenHouse;

public class PT {
	public static int HAM = 300;
	public static int DDUK = 400;
}
