package com.javalec.Interface;

public interface InterEx {
	
	
	public void cal();
}
