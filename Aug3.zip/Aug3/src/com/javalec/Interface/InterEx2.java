package com.javalec.Interface;

public interface InterEx2 {

	public String getStr();
}
