package com.javalec.Interface;

public class Interface implements InterEx, InterEx2{

	@Override
	public String getStr() {
		// TODO Auto-generated method stub
		System.out.println("구현은 여기서합시당! getStr");
		return null;
	}

	@Override
	public void cal() {
		// TODO Auto-generated method stub
		System.out.println("구현은 여기서합시당! cal");
	}
	
}
