package com.javalec.Interface;

public class MainClass {
	public static void main(String[] args) {
		Interface a = new Interface();
		a.cal();
		a.getStr();
		
		InterEx z = new Interface();
		InterEx2 z2 = new Interface();
		z.cal();
		z2.getStr();
	}
}
