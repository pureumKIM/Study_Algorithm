package com.javalec.PapaPouch;

public class FirstChild {
	public FirstChild() {
		// TODO Auto-generated constructor stub
	}
	
	public void takemoney(int don) {
		// TODO Auto-generated method stub
		PapaPouch.MONEY = PapaPouch.MONEY-don;
	}
}
