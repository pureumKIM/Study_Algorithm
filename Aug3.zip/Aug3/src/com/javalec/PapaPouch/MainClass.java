package com.javalec.PapaPouch;

public class MainClass {
	public static void main(String[] args) {
		FirstChild a = new FirstChild();
		a.takemoney(200);
		System.out.println("아빠 남은 돈은?"+PapaPouch.MONEY);
	}
}
