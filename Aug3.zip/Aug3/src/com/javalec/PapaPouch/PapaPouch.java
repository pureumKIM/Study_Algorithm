package com.javalec.PapaPouch;

public class PapaPouch {
	public PapaPouch() {
		// TODO Auto-generated constructor stub
	}
	public static int MONEY=300;
}
