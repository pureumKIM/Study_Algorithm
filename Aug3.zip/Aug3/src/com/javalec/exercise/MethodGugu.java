package com.javalec.exercise;

public class MethodGugu {
	public static void main(String[] args) {
		MethodGugu a = new MethodGugu();
		a.gugu(3);
	}
	
	void gugu(int num){
		for(int i=1; i<10; i++){
			System.out.println(num+"*"+i+"="+(num*i));
		}
	}
	
}


