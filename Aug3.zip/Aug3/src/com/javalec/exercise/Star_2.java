package com.javalec.exercise;

public class Star_2 {
	public static void main(String[] args) {
		int num = 5;
		for(int i=1; i<=num;i++){
			for(int j=1; j<num-i+1;j++){
				System.out.print(" ");
			}
			for(int k=num-i+1;k<num+i;k++){
				System.out.print("*");
			}
			System.out.println("");
		}
	}
}
