package com.javalec.exercise;

public class WhileReturn {
	public static void main(String[] args) {
		int num = 78;
		int i=1;
		while(true){
			if(i%num==0){
				System.out.println(i);
				return;
			}
			i++;
		}
	}
}
