package com.javalec.exercise;

public class WhileThreeHap {
	public static void main(String[] args) {
		int i = 1;
		int hap = 0;
		while(i<100){
			if(i%3==0){
				hap += i;
			}
			i++;
		}
		System.out.println(hap);
	}
}
