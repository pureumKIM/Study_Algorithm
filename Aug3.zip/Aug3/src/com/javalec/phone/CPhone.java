package com.javalec.phone;

public class CPhone implements IFunction {

	@Override
	public void remote() {
		// TODO Auto-generated method stub
		System.out.println("리모컨 불가능");
	}

	@Override
	public void call() {
		// TODO Auto-generated method stub
		System.out.println("전화 불가능");
	}

	@Override
	public void lte() {
		// TODO Auto-generated method stub
		System.out.println("lte 가능");
	}

}
