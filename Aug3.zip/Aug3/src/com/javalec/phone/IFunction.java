package com.javalec.phone;

public interface IFunction {
	public void remote();
	public void call();
	public void lte();
}
