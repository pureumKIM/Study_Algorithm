package com.javalec.phone;

public class MainClass {
	public static void main(String[] args) {
		IFunction a = new APhone();
		IFunction b = new BPhone();
		IFunction c = new CPhone();
		
		IFunction[] iFunction = {a,b,c};
		
		for(int i=0; i<iFunction.length; i++){
			iFunction[i].remote();
			iFunction[i].call();
			iFunction[i].lte();
			System.out.println("====================");
		}
	}
}
