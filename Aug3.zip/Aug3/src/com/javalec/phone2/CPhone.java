package com.javalec.phone2;

public class CPhone implements IFunction {
	public CPhone() {
		// TODO Auto-generated constructor stub
		System.out.println("CPhone 입니다.");
		Lte();
		call();
		remote();
	}
	@Override
	public void Lte() {
		// TODO Auto-generated method stub
		System.out.println("LTE 불가능합니다.");
	}

	@Override
	public void call() {
		// TODO Auto-generated method stub
		System.out.println("전화불가능합니다.");
	}

	@Override
	public void remote() {
		// TODO Auto-generated method stub
		System.out.println("리모컨 가능합니다.");
	}
}
