package com.javalec.phone2;

public interface IFunction {
	void Lte();
	void call();
	void remote();
}
