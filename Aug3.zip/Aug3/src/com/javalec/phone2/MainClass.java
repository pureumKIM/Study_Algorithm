package com.javalec.phone2;

public class MainClass {
	public static void main(String[] args) {
		IFunction a = new APhone();
		IFunction b = new BPhone();
		IFunction c = new CPhone();

	}
}
