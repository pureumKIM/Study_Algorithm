package com.javalec.poly;

public class Actress implements FireFiter, Cook, Police {

	@Override
	public void find() {
		// TODO Auto-generated method stub
		System.out.println("사람찾기");
	}

	@Override
	public void take() {
		// TODO Auto-generated method stub
		System.out.println("구출하기");
	}

	@Override
	public void makePizza() {
		// TODO Auto-generated method stub
		System.out.println("피자만들기");
	}

	@Override
	public void makePasta() {
		// TODO Auto-generated method stub
		System.out.println("파스타만들기");
	}

	@Override
	public void putOff() {
		// TODO Auto-generated method stub
		System.out.println("불끄기");
	}

	@Override
	public void savePerson() {
		// TODO Auto-generated method stub
		System.out.println("사람구하기");
	}

}
