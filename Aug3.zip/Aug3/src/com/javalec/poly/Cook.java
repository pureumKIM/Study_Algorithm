package com.javalec.poly;

public interface Cook {
	void makePizza();
	void makePasta();
}
