package com.javalec.poly;

public interface FireFiter {
	void putOff();
	void savePerson();
}
