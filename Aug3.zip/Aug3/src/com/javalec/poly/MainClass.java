package com.javalec.poly;

public class MainClass {
	public static void main(String[] args) {
		Actress pu = new Actress();
		pu.find();
		pu.take();
		pu.makePasta();
		pu.makePizza();
		pu.putOff();
		pu.savePerson();
		
		Cook ho = new Actress();
		ho.makePasta();
		ho.makePizza();

	}
	
}
