package com.javalec.poly;

public interface Police {
	void find();
	void take();
}
