package com.javalec.poly2;

public class Actress implements FireFiter,Police,Cook {

	@Override
	public void makePizza() {
		// TODO Auto-generated method stub
		System.out.println("피자만들기");
	}

	@Override
	public void makePasta() {
		// TODO Auto-generated method stub
		System.out.println("파스타 만들기");
	}

	@Override
	public void find() {
		// TODO Auto-generated method stub
		System.out.println("사람찾기");
	}

	@Override
	public void arrange() {
		// TODO Auto-generated method stub
		System.out.println("교통정리");
	}

	@Override
	public void putOut() {
		// TODO Auto-generated method stub
		System.out.println("불끄기");
	}

	@Override
	public void savePerson() {
		// TODO Auto-generated method stub
		System.out.println("사람구하기");
	}

}
