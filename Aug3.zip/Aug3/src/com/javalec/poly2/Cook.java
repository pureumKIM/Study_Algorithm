package com.javalec.poly2;

public interface Cook {
	void makePizza();
	void makePasta();
}
