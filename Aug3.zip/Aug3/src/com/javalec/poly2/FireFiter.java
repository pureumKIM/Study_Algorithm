package com.javalec.poly2;

public interface FireFiter {
	void putOut();
	void savePerson();
}
