package com.javalec.poly2;

public class MainClass {
	public static void main(String[] args) {
		Actress pu = new Actress();
		pu.arrange();
		FireFiter a = new Actress();
		a.putOut();
		//a.makePasta();
	}
}
