package com.javalec.poly2;

public interface Police {
	void find();
	void arrange();
}
