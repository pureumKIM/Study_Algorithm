package com.javalec.toyland;

public class AirplaneClass implements missile, light {
	public AirplaneClass() {
		// TODO Auto-generated constructor stub
		System.out.println("저는 비행기입니다.");
		canLight();
		canMissile();
		System.out.println("======================");
	}
	
	@Override
	public void canLight() {
		// TODO Auto-generated method stub
		System.out.println("불빛을 낼 수 있어요.");
	}

	@Override
	public void canMissile() {
		// TODO Auto-generated method stub
		System.out.println("미사일을 쏠 수 있어요.");
	}

}
