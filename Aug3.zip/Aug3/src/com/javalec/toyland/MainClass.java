package com.javalec.toyland;

public class MainClass {
	public static void main(String[] args) {
		toy a = new PoohClass();
		toy b = new RobotClass();
		toy c = new AirplaneClass();
		
		toy[] toys = {a,b,c};
	}
}
