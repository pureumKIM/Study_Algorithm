package com.javalec.toyland;

public class PoohClass implements move{
	public PoohClass() {
		// TODO Auto-generated constructor stub
		System.out.println("저는 곰돌이입니다.");
		canMove();
		System.out.println("======================");
	}
	@Override
	public void canMove() {
		// TODO Auto-generated method stub
		System.out.println("팔다리를 움직일 수 있어요.");
	}

}
