package com.javalec.toyland;

public interface light extends toy {
	void canLight();
}
