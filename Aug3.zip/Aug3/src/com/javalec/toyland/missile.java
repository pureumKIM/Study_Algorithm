package com.javalec.toyland;

public interface missile extends toy {
	void canMissile();
}
