package com.javalec.toyland;

public interface move extends toy {
	void canMove();
}
