package com.javalec.toyland;

public interface toy {

}
