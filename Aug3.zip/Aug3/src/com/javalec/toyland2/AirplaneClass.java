package com.javalec.toyland2;

public class AirplaneClass implements light, missile {

	public AirplaneClass() {
		// TODO Auto-generated constructor stub
		System.out.println("비행기랍니당.");
		canLight();
		canMissile();
		System.out.println("======================");
	}
	
	@Override
	public void canLight() {
		// TODO Auto-generated method stub
		System.out.println("빛을 낼 수 있어요");
	}

	@Override
	public void canMissile() {
		// TODO Auto-generated method stub
		System.out.println("미사일 발사 가능합니다.");
	}
}
