package com.javalec.toyland2;

public class MainClass {
	public static void main(String[] args) {
		toy pooh = new PoohClass();
		toy robot = new RobotClass();
		toy airplane = new AirplaneClass();
	}
}
