package com.javalec.toyland2;

public class PoohClass implements move {
	
	
	public PoohClass() {
		// TODO Auto-generated constructor stub
		System.out.println("곰돌이 입니다.");
		canMove();
		System.out.println("============================");
	}
	
	
	@Override
	public void canMove() {
		// TODO Auto-generated method stub
		System.out.println("움직일수 있어요!");
	}

}
