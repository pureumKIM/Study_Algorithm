package com.javalec.toyland2;

public class RobotClass implements move, light {
	
	public RobotClass() {
		// TODO Auto-generated constructor stub
		System.out.println("로봇입니당 ㅎㅎ");
		canMove();
		canLight();
		System.out.println("=============================");
	}
	
	@Override
	public void canMove() {
		// TODO Auto-generated method stub
		System.out.println("움직일수 있어요!");
	}

	@Override
	public void canLight() {
		// TODO Auto-generated method stub
		System.out.println("빛을 낼 수 있어요");
	}
}
