package com.javalec.toyland2;

public interface light extends toy {
	void canLight();
}
