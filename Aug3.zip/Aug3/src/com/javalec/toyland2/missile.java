package com.javalec.toyland2;

public interface missile extends toy {
	void canMissile();
}
