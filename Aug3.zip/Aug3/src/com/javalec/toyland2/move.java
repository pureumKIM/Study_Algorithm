package com.javalec.toyland2;

public interface move extends toy {
	void canMove();
}
