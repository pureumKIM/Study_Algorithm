package com.javalec.toyland2;

public interface toy {

}
